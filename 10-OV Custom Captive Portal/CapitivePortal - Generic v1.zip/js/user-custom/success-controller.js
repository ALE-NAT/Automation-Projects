/**
 * Created by chenqk on 2018/6/6.
 */
/**
 * Created by chenqk on 2018/6/6.
 */

angular.module('main')
    .controller("successController", ["$scope","$translate",'$http',function ($scope,$translate,$http) {

    }]);