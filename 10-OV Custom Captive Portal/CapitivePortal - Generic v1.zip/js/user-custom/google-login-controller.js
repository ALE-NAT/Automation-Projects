/**
 * Created by chenqk on 2018/6/6.
 */
/**
 * Created by chenqk on 2018/6/6.
 */

angular.module('main')
    .controller("googleLoginController", function ($scope, $translate, $http, mainActionService, localStorageService, $window, mainService) {
        var vm = this;
        vm.welcome_logo = welcome_logo;
        var mac = localStorageService.get("mac");
        var portalURL = localStorageService.get("url");
        var backurl = localStorageService.get("backurl");
        var serviveLevel = parseInt(localStorageService.get('serviveLevel'));

        var useragent = $window.navigator.userAgent;
        var rules = ['WebView', '(iPhone|iPod|iPad)(?!.*Safari\/)', 'Android.*(wv|\.0\.0\.0)', 'Linux; U; Android'];
        var regex = new RegExp(rules.join('|'), 'ig');
        var webview = Boolean(useragent.match(regex));

        var logoBg = typeof (welcomeLogoBgColor) === "undefined" ? null : welcomeLogoBgColor;
        vm.welcomeBgColor = (typeof (welcomeBgColor) === "undefined" || !welcomeBgColor) ? "rgb(255, 250, 253, 0.9)" : welcomeBgColor;
        vm.welcomeBgSrc = (typeof (welcome_bg_src) === "undefined" || !welcome_bg_src) ? "img/bg-default.jpg" : welcome_bg_src;

        $scope.logoBg = mainService.setLogoBackground(logoBg);
        $scope.welcomeBgColorStyle = mainService.setBgStyle(vm.welcomeBgColor);
        $scope.welcomeBgStyle = mainService.setBgStyle(null, vm.welcomeBgSrc, 'no-repeat');

        mainActionService.decorator(vm, $scope);

        if (webview) {
            vm.action.openDialog(false, 'login.errorMessage.useBrowser');
        } else {
            var client = new jso.JSO({
                providerID: "google",
                client_id: googleID,
                redirect_uri: $window.location.href,
                authorization: "https://accounts.google.com/o/oauth2/v2/auth",
                scopes: { request: ['email'] },
                response_type: 'token'
            });
            client.callback();
            client.getToken()
                .then(function () {
                    var f = new jso.Fetcher(client);
                    var url = 'https://openidconnect.googleapis.com/v1/userinfo';
                    f.fetch(url, {})
                        .then(function (resp) {
                            return resp.json();
                        })
                        .then(function (resp) {
                            var data = {
                                username: resp.sub,
                                strategyName: strategyInfo,
                                useFor: "Guest",
                                mac: mac,
                                url: portalURL,
                                serviceLevel: serviveLevel
                            };
                            $http({
                                url: "/portal/api/ham/login/socialAccount",
                                method: "POST",
                                data: data
                            }).then(function (response) {
                                if (response.data.errorCode == 0) {
                                    localStorageService.set('_login_provider', "google");
                                    if (response.data.data) {
                                        $window.location.href = "success.html?mac=" + data.mac + "&username=" + data.username + "&useFor=" + data.useFor + "&backurl=" + backurl + "&fixandinit=" + response.data.data;
                                    }
                                    else {
                                        $window.location.href = "success.html?mac=" + data.mac + "&username=" + data.username + "&useFor=" + data.useFor + "&backurl=" + backurl;
                                    }
                                }
                                else {
                                    vm.action.openDialog(true, response.data.errorMessage, vm, $scope);
                                    vm.modalInstance.result.then(function () {
                                        $window.location.href = localStorageService.get('loginUrl');
                                    });
                                }
                            }, function (response) {
                                vm.action.openDialog(true, $translate.instant("upam.confirmMsg.innerError") + " :" + response.status);
                                vm.modalInstance.result.then(function () {
                                    $window.location.href = localStorageService.get('loginUrl');
                                });
                            });
                        })
                        .catch(function (err) {
                            vm.action.openDialog(true, $translate.instant("upam.confirmMsg.innerError") + " :" + err.message);
                            vm.modalInstance.result.then(function () {
                                $window.location.href = localStorageService.get('loginUrl');
                            });
                            console.error("Error from fetcher", err)
                        });
                });
        }
    });


